Things to do :D and some notes you´d maybe like to read (english isnt my first language so probably there are some grammar errors here, sorry i did my best)


-----------------------------------------------------------------------------------------------------------------------------------

-NOTES

- THE VACCINATOR IS SO FUCKED UP IN MINMODE IM SORRY I DID MY BEST
- srry if minmode and the killstreak count look a bit lazy, i will try to improve them later ^^!
- Other than that, the main and most of the things you'd expect from a hud and in game things are finished and work correctly :DD (or atleast for me...) Enjoy!
- when i was doing this txt file i accidentally deleted it so i had to do a new one and write everything again so maybe a forgot some things qwq

-----------------------------------------------------------------------------------------------------------------------------------

-TO DO!

- holishit i forgot the eureka effect menu
- More Main menu pixel art buttons
- backpack menu
- Pixel art images for the casual menu gamemodes
- pixel art cp, payload and ctf icons (on it)
- acomodate payload icons in normal mode (kinda done)
- Edit Team selection and welcome panels
- Gamemode selection panel (on it)
- Loadout menus and pixel art icons and borders
- time clock pixel art
- win and loss panel
- Make most text buttons change to yellow when selected and clicked and change their font
- change and add most pixel art borders and boxes
- change most menus and loading screens
- move and change side effects icons to pixel art ones (soldier´s buffs, marked for death, jarate, mad milk, parachute, etc.) (kinda done i think)
- MVM hud ( i just did the currency, cantines and a heavy meter :P)
- change font of health and metal regen
- 3:4, linux, etc. maybe yes, maybe not when i finish it (that seems hard ono)
- thats kinda it or maybe not i forgor


							-in less words, more pixel art where isn't-

----------------------------------------------------------------------------------------------------------------------------------

-Done things !!!
- spy disguise info bg and font (✔️ done!)
- move engie´s and spie´s menus (✔️ done!)
- spy disguise info bg and font (✔️ done!)
- move engie´s and spie´s menus (✔️ done!)
- Scoreboard (done but i might improve it a bit)
- killfeed ( kinda done? idk what else do with it )
-----------------------------------------------------------------------------------------------------------------------------------